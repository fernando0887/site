from flask import redirect, render_template, url_for, flash, request
from loja import db, app
from .models import Marcas, Categoria
from .forms import Addprodutos

@app.route('/addmarca', methods=['GET', 'POST'])

def addmarca():
    if request.method == 'POST':
        getmarca = request.form.get('marca')
        marca = Marcas(name=getmarca)
        db.session.add(marca)
        db.session.commit()
        flash(f'Marca {getmarca} cadastrada com sucesso!', 'success')
        return redirect(url_for('addmarca'))
    return render_template('/produtos/addmarca.html', marcas='marcas')



@app.route('/addcat', methods=['GET', 'POST'])

def addcat():
    if request.method == 'POST':
        getmarca = request.form.get('categoria')
        cat = Categoria(name=getmarca)
        db.session.add(cat)
        db.session.commit()
        flash(f'Categoria {getmarca} cadastrada com sucesso!', 'success')
        return redirect(url_for('addcat'))
    return render_template('/produtos/addmarca.html')


@app.route('/addproduto', methods=['GET', 'POST'])

def addproduto():
    form= Addprodutos(request.form)
    
    return render_template('/produtos/addproduto.html', title= 'Cadastrar Produtos', form= form)